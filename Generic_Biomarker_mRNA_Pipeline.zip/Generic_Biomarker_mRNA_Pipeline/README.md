# Generic_mRNA_Expression_Pipeline

This is the generic mRNA Analysis pipeline AG Leser, Institute for Computer Science Humboldt University Berlin, Germany
